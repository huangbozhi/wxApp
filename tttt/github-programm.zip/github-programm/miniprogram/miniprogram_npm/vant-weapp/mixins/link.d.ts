export declare const link: void;
